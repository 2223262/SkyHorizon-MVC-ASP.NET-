USE SkyHorizon;

SET @dbname = DATABASE();
SET @tablename = 'Users';
SET @columnname = 'Email';
SET @preparedStatement = (SELECT IF(
  (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
   WHERE TABLE_SCHEMA = @dbname
     AND TABLE_NAME = @tablename
     AND COLUMN_NAME = @columnname
  ) > 0,
  'SELECT 1',
  'ALTER TABLE Users ADD COLUMN Email VARCHAR(255) NOT NULL AFTER Password'
));
PREPARE stmt FROM @preparedStatement;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

ALTER TABLE Users MODIFY COLUMN Role VARCHAR(50) DEFAULT 'User';

DELETE FROM Bookings;
DELETE FROM Destinations;
DELETE FROM Users;

INSERT INTO Users (Username, Password, Email, Role) 
VALUES ('admin', 'admin', 'admin@skyhorizon.com', 'Admin');

INSERT INTO Destinations (Id, Name, Country, Description, Image, DistanceFromPortugal) VALUES
(1, 'Paris', 'França', 'A Cidade da Luz, conhecida pela Torre Eiffel, museus de classe mundial e culinária excelente.', 'y34Q4sYi9OZt.jpeg', 1500),
(2, 'Barcelona', 'Espanha', 'Uma cidade vibrante com arquitetura única de Gaudí, praias e vida noturna animada.', 'OG3SilvlAOi7.jpg', 800),
(3, 'Roma', 'Itália', 'A capital histórica com o Coliseu, Vaticano e uma riqueza de arte e cultura.', '4upKqfzcjuOq.jpeg', 2000),
(4, 'Amesterdão', 'Holanda', 'Canais pitorescos, museus renomados e uma atmosfera acolhedora e descontraída.', 'Som3MyMD31GN.jpg', 1800),
(5, 'Berlim', 'Alemanha', 'Uma cidade histórica com arte moderna, vida noturna vibrante e história rica.', 'hgYoXazpqTwj.jpg', 2200),
(6, 'Londres', 'Reino Unido', 'Capital britânica com Big Ben, Palácio de Buckingham e museus fascinantes.', '1WygKbuiacbx.jpg', 1600),
(7, 'Istambul', 'Turquia', 'Uma cidade mágica entre dois continentes, com história, cultura e gastronomia.', '9fkKFRmZZIau.jpg', 2800),
(8, 'Dubai', 'Emirados Árabes', 'Luxo moderno no deserto, com arranha-céus impressionantes e compras de classe mundial.', 'ilDnCFg2XPsH.jpg', 5000),
(9, 'Tóquio', 'Japão', 'Uma metrópole futurista com tradição, tecnologia e uma cena gastronômica incrível.', 'Lbk9FXlL2RUF.jpg', 10000),
(10, 'Sydney', 'Austrália', 'Praias paradisíacas, a Ópera icônica e um estilo de vida ao ar livre.', 'PvYDr2VJB0fq.jpg', 12000),
(11, 'Nova Iorque', 'EUA', 'A cidade que nunca dorme, com Broadway, Central Park e uma energia incomparável.', 'VYCtrNDLAMCM.jpg', 5800),
(12, 'Bangkok', 'Tailândia', 'Templos dourados, mercados flutuantes e comida de rua deliciosa.', 'Gn0AkmQJu0iH.jpeg', 8500);
